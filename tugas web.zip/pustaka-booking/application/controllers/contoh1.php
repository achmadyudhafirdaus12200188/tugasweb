<?php
class contoh1 extends CI_controller
{
    public function index()
    {
        echo "<h1>perkenalkan</h1>";
        echo "Nama saya Muhammad Ramzy Fawwaz
        saya tinggal di daerah Cikupa
        olahraga yang saya sukai adalah futsal";
    }

}