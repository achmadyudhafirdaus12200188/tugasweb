<div class="container">
    <!-- Outer Row -->
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb4">Halaman Login!!</h1>
                                </div>
                                <?= $this->session->flashdata('pesan'); ?>
                                <form class="user" method="post" action="<?= base_url('autentifikasi'); ?>">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" value="<?=
                                                                                                            set_value('email'); ?>" id="email" placeholder="Masukkan Alamat 
Email" name="email">
                                        <?= form_error(
                                            'email',
                                            '<small class="text-danger pl-3">',
                                            '</small>'
                                        ); ?>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user" id="password" placeholder="Password" name="password">
                                        <?= form_error(
                                            'password',
                                            '<small class="text-danger pl-3">',
                                            '</small>'
                                        ); ?>
                                    </div>
                                    <button type="submit" class="btn 
btn-primary btn-user btn-block">
                                        Masuk
                                    </button>
                                </form>
                                <hr>
                                <div class="text-center">
                                    <a class="small" href="<?=
                                                            base_url('autentifikasi/lupaPassword'); ?>">Lupa Password?</a>
                                </div>
                                <div class="text-center">
                                    <a class="small" href="<?=
                                                            base_url('autentifikasi/registrasi'); ?>">Daftar Member!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mxauto">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb4">Daftar Menjadi Member!</h1>
                        </div>
                        <form class="user" method="post" action="<?= base_url('autentifikasi/registrasi'); ?>">
                            <div class="clearfix _58mh"><div class="mbm _1iy_ _a4y _3-90 lfloat _ohe"><div class="_5dbb" id="u_6_a_sB"><div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput"><div class="placeholder" aria-hidden="true">Nama depan</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="firstname" value="" aria-required="true" placeholder="" aria-label="Nama depan" id="u_6_b_Ql" tabindex="0" aria-describedby="js_5x" aria-invalid="true"></div><i class="_5dbc img sp_98fCI7IVTTz sx_54513f"></i><i class="_5dbd img sp_98fCI7IVTTz sx_336c7a"></i><div class="_1pc_"></div></div></div><div class="mbm _1iy_ _a4y rfloat _ohf"><div class="_5dbb" id="u_6_c_0J"><div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput"><div class="placeholder" aria-hidden="true">Nama belakang</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="lastname" value="" aria-required="true" placeholder="" aria-label="Nama belakang" id="u_6_d_fO"></div><i class="_5dbc img sp_98fCI7IVTTz sx_54513f"></i><i class="_5dbd img sp_98fCI7IVTTz sx_336c7a"></i><div class="_1pc_">
                                <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput"><div class="placeholder" aria-hidden="true">Nomor seluler atau email</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="reg_email__" value="" aria-required="true" placeholder="" aria-label="Nomor seluler atau email" id="u_6_g_NG">
                            </div>
                            <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput"><div class="placeholder" aria-hidden="true">Kata sandi baru</div><input type="password" class="inputtext _58mg _5dba _2ph-" data-type="password" autocomplete="new-password" name="reg_passwd__" id="password_step_input" aria-required="true" placeholder="" aria-label="Kata sandi baru">
                                </div>
                            </div>
                            <button type="submit" class="btn btnprimary btn-user btn-block">
                                Daftar Menjadi Member
                            </button>
                        </form>
                        <hr>
                        <div class="text-center">
                            <a class="small" href="<?=
                                                    base_url('autentifikasi/lupaPassword'); ?>">Lupa Password?</a>
                        </div>
                        <div class="text-center">
                            Sudah Menjadi Member?<a class="small" href="<?= base_url('autentifikasi'); ?>"> Login!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>