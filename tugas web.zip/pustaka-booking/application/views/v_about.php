<section>
    <h1><?php echo $judul ?></h1>
    <h3>About page</h3>
    <ul type="square">
        <li>Selamat Datang ganteng</li>
    </ul>
</section>