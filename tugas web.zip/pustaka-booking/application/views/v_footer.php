        <footer>
            <a href="https://www.RentalBuku.com">RentalBuku</a>
        </footer>

        </body>

        </html>
        </div>