<section>
    <h1><?php echo $judul ?></h1>
    <p align='justify'>Selamat Datang pada halaman Home</p>
</section>