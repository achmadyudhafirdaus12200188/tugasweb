<section>
    <h2>Halaman Profil</h2>
    <p>Haaaii salam kenal semuaa</p> <br>
    <p>Nama : Achmad Yudha Firdaus</p> <br>
    <p>NIM : 12200188</p> <br>
    <p>Kelas : 12.3A.03</p> <br>
    <p>Jurusan : cimone-balaraja</p>
</section>